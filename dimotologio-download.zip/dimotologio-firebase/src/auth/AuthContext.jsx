import { createContext, useContext, useEffect, useMemo, useState } from "react";
import { onAuthStateChanged, signOut, getIdTokenResult } from "firebase/auth";
import { doc, onSnapshot } from "firebase/firestore";
import { httpsCallable } from "firebase/functions";
import { auth, authPersistenceReady, db, functions } from "../firebase";

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [profile, setProfile] = useState(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let stopProfile = null;
    const stopAuth = onAuthStateChanged(auth, async (nextUser) => {
      if (stopProfile) stopProfile();
      stopProfile = null;
      setUser(nextUser);
      setProfile(null);
      setIsAdmin(false);
      if (!nextUser) {
        setLoading(false);
        return;
      }
      setLoading(true);
      try {
        await authPersistenceReady;
        const token = await getIdTokenResult(nextUser, true);
        setIsAdmin(token.claims.admin === true);
        // Server function creates a minimal pending citizen profile if needed.
        if (token.claims.admin !== true) {
          await httpsCallable(functions, "ensureCitizenProfile")({});
          stopProfile = onSnapshot(doc(db, "users", nextUser.uid), (snap) => {
            setProfile(snap.exists() ? snap.data() : null);
            setLoading(false);
          }, () => setLoading(false));
        } else {
          setLoading(false);
        }
      } catch (error) {
        console.error("Authentication initialization failed", error);
        setLoading(false);
      }
    });
    return () => { stopAuth(); if (stopProfile) stopProfile(); };
  }, []);

  const value = useMemo(() => ({
    user, profile, isAdmin, loading,
    logout: () => signOut(auth),
    refreshClaims: async () => {
      if (!auth.currentUser) return;
      const token = await getIdTokenResult(auth.currentUser, true);
      setIsAdmin(token.claims.admin === true);
    },
  }), [user, profile, isAdmin, loading]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}
export function useAuth() {
  const value = useContext(AuthContext);
  if (!value) throw new Error("useAuth must be used within AuthProvider");
  return value;
}