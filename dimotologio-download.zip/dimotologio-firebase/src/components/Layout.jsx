import { NavLink, Outlet, useNavigate } from "react-router-dom";
import { Landmark, LayoutDashboard, FileText, Users, LogOut, ShieldCheck } from "lucide-react";
import { useAuth } from "../auth/AuthContext";

export default function Layout({ admin = false }) {
  const { logout, user, profile } = useAuth();
  const navigate = useNavigate();
  async function handleLogout() { await logout(); navigate("/login"); }
  return <div className="app-shell">
    <aside className="sidebar">
      <div className="brand"><div className="brand-icon"><Landmark size={23}/></div><div><strong>Δημοτολόγιο</strong><small>Ψηφιακές υπηρεσίες Δήμου</small></div></div>
      <div className="nav-label">{admin ? "ΔΙΑΧΕΙΡΙΣΗ" : "ΠΟΛΙΤΗΣ"}</div>
      {admin ? <>
        <NavLink to="/admin" end className="nav-link"><LayoutDashboard size={18}/> Επισκόπηση</NavLink>
        <NavLink to="/admin/requests" className="nav-link"><FileText size={18}/> Αιτήματα</NavLink>
        <NavLink to="/admin/citizens" className="nav-link"><Users size={18}/> Έλεγχος πολιτών</NavLink>
      </> : <>
        <NavLink to="/portal" end className="nav-link"><LayoutDashboard size={18}/> Αρχική</NavLink>
        <NavLink to="/portal/new-request" className="nav-link"><FileText size={18}/> Νέο αίτημα</NavLink>
      </>}
      <div className="sidebar-bottom">
        <div className="account"><div className="avatar"><ShieldCheck size={18}/></div><div className="account-text"><strong>{admin ? "Διαχειριστής" : "Πολίτης"}</strong><small>{user?.phoneNumber || user?.email || profile?.phoneNumber || ""}</small></div></div>
        <button className="nav-link logout" onClick={handleLogout}><LogOut size={18}/> Αποσύνδεση</button>
      </div>
    </aside>
    <main className="main-area">
      <header className="topbar"><span>Ψηφιακός Δήμος</span><span className="secure"><ShieldCheck size={16}/> Ασφαλής σύνδεση</span></header>
      <div className="page-content"><Outlet /></div>
      <footer>Δημοτολόγιο · Πρόσβαση μόνο σε εξουσιοδοτημένους χρήστες</footer>
    </main>
  </div>;
}