import { Navigate, useLocation } from "react-router-dom";
import { useAuth } from "../auth/AuthContext";

export default function Protected({ children, admin = false }) {
  const { user, profile, isAdmin, loading } = useAuth();
  const location = useLocation();
  if (loading) return <div className="center-state">Φόρτωση…</div>;
  if (!user) return <Navigate to="/login" replace state={{ from: location.pathname }} />;
  if (admin && !isAdmin) return <Navigate to="/portal" replace />;
  if (!admin && isAdmin) return <Navigate to="/admin" replace />;
  if (!admin && profile?.status !== "approved") return <Navigate to="/verification" replace />;
  return children;
}