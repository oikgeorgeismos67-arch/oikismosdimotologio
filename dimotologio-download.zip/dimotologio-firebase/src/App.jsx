import { Navigate, Route, Routes } from "react-router-dom";
import { useAuth } from "./auth/AuthContext";
import Protected from "./components/Protected";
import Layout from "./components/Layout";
import Login from "./pages/Login";
import Verification from "./pages/Verification";
import Portal from "./pages/Portal";
import NewRequest from "./pages/NewRequest";
import Admin from "./pages/Admin";
import Requests from "./pages/Requests";
import Citizens from "./pages/Citizens";

export default function App() {
  const { user, isAdmin, profile, loading } = useAuth();
  if (loading) return <div className="center-state">Φόρτωση εφαρμογής…</div>;
  const home = !user ? "/login" : isAdmin ? "/admin" : profile?.status === "approved" ? "/portal" : "/verification";
  return <Routes>
    <Route path="/login" element={<Login/>}/>
    <Route path="/verification" element={user && !isAdmin ? <Verification/> : <Navigate to={home} replace/>}/>
    <Route path="/admin" element={<Protected admin><Layout admin/></Protected>}>
      <Route index element={<Admin/>}/>
      <Route path="requests" element={<Requests/>}/>
      <Route path="citizens" element={<Citizens/>}/>
    </Route>
    <Route path="/portal" element={<Protected><Layout/></Protected>}>
      <Route index element={<Portal/>}/>
      <Route path="new-request" element={<NewRequest/>}/>
    </Route>
    <Route path="*" element={<Navigate to={home} replace/>}/>
  </Routes>;
}