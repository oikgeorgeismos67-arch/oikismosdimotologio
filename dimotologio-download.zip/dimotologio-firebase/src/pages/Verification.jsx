import { Clock3, ShieldCheck } from "lucide-react";
import { useAuth } from "../auth/AuthContext";

export default function Verification() {
  const { profile, user, logout } = useAuth();
  const status = profile?.status || "pending";
  return <div className="verification-wrap"><div className="verification-card">
    <div className="status-icon"><Clock3 size={30}/></div><p className="eyebrow dark">ΕΛΕΓΧΟΣ ΣΤΟΙΧΕΙΩΝ</p>
    <h1>{status === "rejected" ? "Απαιτείται επικοινωνία με τον Δήμο" : "Το αίτημά σας είναι υπό έλεγχο"}</h1>
    <p className="muted">{status === "rejected" ? "Η ενεργοποίηση δεν ολοκληρώθηκε. Επικοινωνήστε με την αρμόδια υπηρεσία για διευκρινίσεις." : "Έχει επιβεβαιωθεί ο αριθμός κινητού σας. Για την προστασία των προσωπικών δεδομένων, εξουσιοδοτημένος υπάλληλος πρέπει να επαληθεύσει τη σχέση σας με το δημοτολόγιο."}</p>
    <div className="review-details"><div><span>Λογαριασμός</span><strong>{user?.phoneNumber}</strong></div><div><span>Κατάσταση</span><strong className="pending-label">{status === "approved" ? "Ενεργός" : status === "rejected" ? "Χρειάζεται έλεγχος" : "Σε αναμονή"}</strong></div></div>
    <div className="info-strip"><ShieldCheck size={18}/> Μέχρι την ολοκλήρωση του ελέγχου δεν εμφανίζονται στοιχεία δημοτολογίου ή λειτουργίες υποβολής αιτημάτων.</div>
    <button className="secondary-button full" onClick={logout}>Αποσύνδεση</button>
  </div></div>;
}