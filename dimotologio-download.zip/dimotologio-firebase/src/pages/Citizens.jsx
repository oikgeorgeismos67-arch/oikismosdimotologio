import { useEffect, useState } from "react";
import { collection, onSnapshot, query, where, orderBy } from "firebase/firestore";
import { httpsCallable } from "firebase/functions";
import { Check, Search, UserCheck, XCircle } from "lucide-react";
import { db, functions } from "../firebase";

export default function Citizens() {
  const [users,setUsers] = useState([]);
  const [search,setSearch] = useState("");
  const [filter,setFilter] = useState("pending");
  const [busyUid,setBusyUid] = useState("");
  const [message,setMessage] = useState("");
  useEffect(() => {
    const q = query(collection(db,"users"),where("role","==","citizen"),orderBy("createdAt","desc"));
    return onSnapshot(q,s=>setUsers(s.docs.map(d=>({id:d.id,...d.data()}))),()=>setMessage("Δεν ήταν δυνατή η φόρτωση των λογαριασμών."));
  },[]);
  const filtered = users.filter(u=>(filter==="all"||u.status===filter)&&`${u.phoneNumber||""} ${u.id}`.toLowerCase().includes(search.toLowerCase()));
  async function review(uid,decision) {
    const note = decision==="rejected" ? window.prompt("Αιτιολογία/σημείωση για το αρχείο (μην καταχωρείτε περιττά δεδομένα):","") : "";
    if (decision==="rejected" && note===null) return;
    setBusyUid(uid);setMessage("");
    try {
      await httpsCallable(functions,"reviewCitizen")({uid,decision,note:note||""});
      setMessage(decision==="approved"?"Ο λογαριασμός ενεργοποιήθηκε.":"Η ενεργοποίηση απορρίφθηκε.");
    } catch(e) { setMessage("Η ενέργεια απέτυχε. Ελέγξτε δικαιώματα και δοκιμάστε ξανά."); }
    finally {setBusyUid("");}
  }
  return <div className="content-stack">
    <div className="page-heading"><div><p className="eyebrow dark">ΕΛΕΓΧΟΣ ΠΡΟΣΒΑΣΗΣ</p><h1>Επαλήθευση πολιτών</h1><p className="muted">Ενεργοποιήστε πρόσβαση μόνο μετά από έλεγχο ταυτότητας και δημοτολογικής σχέσης εκτός της εφαρμογής.</p></div></div>
    <div className="info-strip"><UserCheck size={18}/> Η επιβεβαίωση SMS επιβεβαιώνει μόνο την κατοχή του τηλεφώνου. Ο υπάλληλος οφείλει να ακολουθεί την εγκεκριμένη διαδικασία επαλήθευσης του Δήμου.</div>
    <section className="panel"><div className="toolbar"><div className="search-box"><Search size={17}/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Αναζήτηση τηλεφώνου ή UID…"/></div><select value={filter} onChange={e=>setFilter(e.target.value)}><option value="pending">Σε αναμονή</option><option value="approved">Εγκεκριμένοι</option><option value="rejected">Απορριφθέντες</option><option value="all">Όλοι</option></select></div>
      {message && <div className="success-box">{message}</div>}
      {filtered.length===0 ? <div className="empty-state"><UserCheck size={28}/><h3>Δεν υπάρχουν λογαριασμοί</h3><p>Οι νέοι χρήστες εμφανίζονται μετά την επαλήθευση του τηλεφώνου τους.</p></div> :
      <div className="table-wrap"><table><thead><tr><th>Τηλέφωνο</th><th>UID λογαριασμού</th><th>Ημερομηνία</th><th>Κατάσταση</th><th>Ενέργειες</th></tr></thead><tbody>{filtered.map(u=><tr key={u.id}><td><strong>{u.phoneNumber || "—"}</strong></td><td className="uid-cell">{u.id}</td><td>{u.createdAt?.toDate?.().toLocaleDateString("el-GR")||"—"}</td><td><span className={`status-pill status-${u.status}`}>{({pending:"Σε αναμονή",approved:"Εγκεκριμένος",rejected:"Απορρίφθηκε"})[u.status]||u.status}</span></td><td><div className="table-actions">{u.status!=="approved"&&<button className="small-button approve" disabled={!!busyUid} onClick={()=>review(u.id,"approved")}><Check size={14}/> Έγκριση</button>}{u.status!=="rejected"&&<button className="small-button reject" disabled={!!busyUid} onClick={()=>review(u.id,"rejected")}><XCircle size={14}/> Απόρριψη</button>}</div></td></tr>)}</tbody></table></div>}
    </section>
  </div>;
}