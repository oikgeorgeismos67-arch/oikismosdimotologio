import { useState } from "react";
import { addDoc, collection, serverTimestamp } from "firebase/firestore";
import { ArrowLeft, FilePlus2, Info } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { db } from "../firebase";
import { useAuth } from "../auth/AuthContext";

const requestTypes = ["Πιστοποιητικό οικογενειακής κατάστασης", "Πιστοποιητικό γέννησης", "Πιστοποιητικό εγγυτέρων συγγενών", "Μεταβολή στοιχείων", "Άλλο αίτημα"];
export default function NewRequest() {
  const { user } = useAuth();
  const [type,setType] = useState(requestTypes[0]);
  const [description,setDescription] = useState("");
  const [busy,setBusy] = useState(false);
  const [error,setError] = useState("");
  const navigate = useNavigate();
  async function submit(e) {
    e.preventDefault(); setBusy(true); setError("");
    try {
      await addDoc(collection(db,"requests"), {
        citizenUid: user.uid, type, description: description.trim(),
        status: "submitted", createdAt: serverTimestamp(), updatedAt: serverTimestamp(),
        attachmentPaths: []
      });
      navigate("/portal");
    } catch (err) {
      console.error(err);
      setError("Δεν ήταν δυνατή η υποβολή. Βεβαιωθείτε ότι ο λογαριασμός σας έχει ενεργοποιηθεί από υπάλληλο.");
    } finally { setBusy(false); }
  }
  return <div className="content-stack narrow">
    <Link to="/portal" className="back-link"><ArrowLeft size={16}/> Επιστροφή στα αιτήματα</Link>
    <div className="page-heading"><div><p className="eyebrow dark">ΗΛΕΚΤΡΟΝΙΚΗ ΥΠΗΡΕΣΙΑ</p><h1>Νέο αίτημα</h1><p className="muted">Περιγράψτε τι χρειάζεστε για να δρομολογηθεί στην αρμόδια υπηρεσία.</p></div></div>
    <div className="info-strip"><Info size={18}/> Μην καταχωρείτε ευαίσθητα δεδομένα που δεν είναι απαραίτητα για την εξέταση του αιτήματος.</div>
    <form className="panel form-stack" onSubmit={submit}>
      <div className="form-title"><FilePlus2 size={22}/><h2>Στοιχεία αιτήματος</h2></div>
      <label htmlFor="request-type">Κατηγορία αιτήματος <span>*</span></label>
      <select id="request-type" value={type} onChange={e=>setType(e.target.value)} required>{requestTypes.map(t=><option key={t}>{t}</option>)}</select>
      <label htmlFor="request-description">Περιγραφή <span>*</span></label>
      <textarea id="request-description" value={description} onChange={e=>setDescription(e.target.value)} minLength={5} maxLength={5000} rows={6} placeholder="Περιγράψτε συνοπτικά το αίτημά σας…" required/>
      <div className="char-count">{description.length}/5000 χαρακτήρες</div>
      {error && <div className="error-box">{error}</div>}
      <div className="form-actions"><Link className="secondary-button" to="/portal">Ακύρωση</Link><button className="primary-button" disabled={busy}>{busy ? "Υποβολή…" : "Υποβολή αιτήματος"}</button></div>
    </form>
  </div>;
}