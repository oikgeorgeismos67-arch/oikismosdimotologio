import { useEffect, useState } from "react";
import { collection, onSnapshot, query, orderBy } from "firebase/firestore";
import { httpsCallable } from "firebase/functions";
import { FileText, Search, RefreshCw, X, CheckCircle2 } from "lucide-react";
import { db, functions } from "../firebase";

const labels = { submitted: "Υποβλήθηκε", in_review: "Σε εξέταση", needs_info: "Απαιτούνται στοιχεία", completed: "Ολοκληρώθηκε", rejected: "Απορρίφθηκε" };
export function StatusPill({status}) { return <span className={`status-pill status-${status || "submitted"}`}>{labels[status] || status || "Υποβλήθηκε"}</span>; }

export default function Requests({compact=false}) {
  const [items,setItems] = useState([]);
  const [filter,setFilter] = useState("all");
  const [search,setSearch] = useState("");
  const [selected,setSelected] = useState(null);
  const [newStatus,setNewStatus] = useState("in_review");
  const [note,setNote] = useState("");
  const [busy,setBusy] = useState(false);
  const [message,setMessage] = useState("");
  useEffect(() => onSnapshot(query(collection(db,"requests"),orderBy("createdAt","desc")), snap => setItems(snap.docs.map(d=>({id:d.id,...d.data()}))), () => setMessage("Δεν ήταν δυνατή η φόρτωση των αιτημάτων."),), []);
  const filtered = items.filter(r => (filter==="all" || r.status===filter) && `${r.type} ${r.id} ${r.citizenUid}`.toLowerCase().includes(search.toLowerCase()));
  async function updateStatus() {
    if (!selected) return;
    setBusy(true);setMessage("");
    try {
      await httpsCallable(functions,"updateRequestStatus")({requestId:selected.id,status:newStatus,note:note.trim()});
      setSelected(null);setNote("");setMessage("Η κατάσταση ενημερώθηκε.");
    } catch (e) { setMessage("Η ενημέρωση απέτυχε. Ελέγξτε τα δικαιώματα και δοκιμάστε ξανά."); }
    finally { setBusy(false); }
  }
  return <div className="content-stack">
    {!compact && <div className="page-heading"><div><p className="eyebrow dark">ΔΙΑΧΕΙΡΙΣΗ ΥΠΟΘΕΣΕΩΝ</p><h1>Ηλεκτρονικά αιτήματα</h1><p className="muted">Έλεγχος, δρομολόγηση και ενημέρωση κατάστασης αιτημάτων.</p></div></div>}
    <section className="panel"><div className="toolbar"><div className="search-box"><Search size={17}/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Αναζήτηση τύπου, κωδικού ή UID…"/></div><select value={filter} onChange={e=>setFilter(e.target.value)}><option value="all">Όλες οι καταστάσεις</option>{Object.entries(labels).map(([k,v])=><option key={k} value={k}>{v}</option>)}</select></div>
      {message && <div className="success-box">{message}</div>}
      {filtered.length===0 ? <div className="empty-state"><FileText size={28}/><h3>Δεν βρέθηκαν αιτήματα</h3><p>Δεν υπάρχουν εγγραφές που να αντιστοιχούν στα κριτήρια.</p></div> :
      <div className="table-wrap"><table><thead><tr><th>Αίτημα</th><th>UID πολίτη</th><th>Ημερομηνία</th><th>Κατάσταση</th><th></th></tr></thead><tbody>{filtered.map(r=><tr key={r.id}><td><strong>{r.type}</strong><small className="table-sub">{r.id}</small></td><td className="uid-cell">{r.citizenUid}</td><td>{formatDate(r.createdAt)}</td><td><StatusPill status={r.status}/></td><td><button className="small-button" onClick={()=>{setSelected(r);setNewStatus(r.status || "submitted");setNote("");}}>Άνοιγμα</button></td></tr>)}</tbody></table></div>}
    </section>
    {selected && <div className="modal-backdrop" onClick={()=>setSelected(null)}><section className="modal-card" onClick={e=>e.stopPropagation()}><div className="modal-head"><div><p className="eyebrow dark">ΛΕΠΤΟΜΕΡΕΙΕΣ</p><h2>{selected.type}</h2></div><button className="icon-button" onClick={()=>setSelected(null)}><X size={20}/></button></div><div className="detail-grid"><div><span>Κωδικός αιτήματος</span><strong>{selected.id}</strong></div><div><span>UID πολίτη</span><strong>{selected.citizenUid}</strong></div><div><span>Ημερομηνία</span><strong>{formatDate(selected.createdAt)}</strong></div></div><div className="description-box"><span>Περιγραφή</span><p>{selected.description}</p></div><div className="form-stack"><label>Νέα κατάσταση</label><select value={newStatus} onChange={e=>setNewStatus(e.target.value)}>{Object.entries(labels).map(([k,v])=><option key={k} value={k}>{v}</option>)}</select><label>Σημείωση προς το ιστορικό (μην καταχωρείτε περιττά προσωπικά δεδομένα)</label><textarea rows={3} value={note} onChange={e=>setNote(e.target.value)} maxLength={1000} placeholder="Σύντομη υπηρεσιακή σημείωση…"/></div><button className="primary-button full" disabled={busy} onClick={updateStatus}><CheckCircle2 size={17}/>{busy ? "Αποθήκευση…" : "Αποθήκευση κατάστασης"}</button></section></div>}
  </div>;
}
function formatDate(ts) { return ts?.toDate ? ts.toDate().toLocaleString("el-GR") : "—"; }