import { useEffect, useState } from "react";
import { collection, onSnapshot, query, orderBy } from "firebase/firestore";
import { Users, FileText, Clock3, CheckCircle2, ArrowUpRight } from "lucide-react";
import { Link } from "react-router-dom";
import { db } from "../firebase";
import { StatusPill } from "./Requests.jsx";

export default function Admin() {
  const [requests,setRequests] = useState([]);
  const [profiles,setProfiles] = useState([]);
  const [error,setError] = useState("");
  useEffect(() => {
    const a = onSnapshot(query(collection(db,"requests"),orderBy("createdAt","desc")),s=>setRequests(s.docs.map(d=>({id:d.id,...d.data()}))),()=>setError("Αποτυχία φόρτωσης αιτημάτων."));
    const b = onSnapshot(collection(db,"users"),s=>setProfiles(s.docs.map(d=>({id:d.id,...d.data()}))),()=>setError("Αποτυχία φόρτωσης χρηστών."));
    return ()=>{a();b();};
  },[]);
  const pending = requests.filter(r=>["submitted","in_review","needs_info"].includes(r.status)).length;
  return <div className="content-stack">
    <div className="page-heading"><div><p className="eyebrow dark">ΚΕΝΤΡΟ ΕΛΕΓΧΟΥ</p><h1>Επισκόπηση</h1><p className="muted">Σύνοψη λειτουργίας και εκκρεμοτήτων του Δημοτολογίου.</p></div><span className="date-chip">{new Date().toLocaleDateString("el-GR",{day:"numeric",month:"long",year:"numeric"})}</span></div>
    {error && <div className="error-box">{error}</div>}
    <div className="stats-grid"><Stat icon={<FileText/>} label="Συνολικά αιτήματα" value={requests.length}/><Stat icon={<Clock3/>} label="Εκκρεμή αιτήματα" value={pending}/><Stat icon={<Users/>} label="Λογαριασμοί πολιτών" value={profiles.filter(p=>p.role==="citizen").length}/><Stat icon={<CheckCircle2/>} label="Ολοκληρωμένα" value={requests.filter(r=>r.status==="completed").length}/></div>
    <section className="panel"><div className="panel-heading"><div><h2>Πρόσφατα αιτήματα</h2><p>Τα πιο πρόσφατα αιτήματα που χρειάζονται παρακολούθηση.</p></div><Link className="text-link" to="/admin/requests">Όλα τα αιτήματα <ArrowUpRight size={15}/></Link></div>
      {requests.length===0 ? <div className="empty-state"><FileText size={28}/><h3>Δεν υπάρχουν αιτήματα ακόμη</h3></div> : <div className="request-list">{requests.slice(0,6).map(r=><div className="request-row" key={r.id}><div className="request-symbol"><FileText size={20}/></div><div className="request-info"><strong>{r.type}</strong><small>UID: {r.citizenUid}</small><small>{r.createdAt?.toDate?.().toLocaleDateString("el-GR") || "Μόλις υποβλήθηκε"}</small></div><StatusPill status={r.status}/></div>)}</div>}
    </section>
    <div className="admin-notice"><ShieldCheckIcon/><div><strong>Υπενθύμιση προστασίας δεδομένων</strong><p>Χρησιμοποιείτε μόνο τα απολύτως αναγκαία δεδομένα. Μην εξάγετε στοιχεία πολιτών σε μη εγκεκριμένα μέσα.</p></div></div>
  </div>;
}
function Stat({icon,label,value}) {return <div className="stat-card"><div className="stat-top"><span>{label}</span><span className="stat-icon">{icon}</span></div><strong>{value}</strong></div>}
function ShieldCheckIcon(){return <span className="notice-icon"><CheckCircle2 size={22}/></span>}