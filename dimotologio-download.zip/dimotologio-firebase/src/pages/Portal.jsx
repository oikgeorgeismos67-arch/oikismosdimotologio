import { useEffect, useState } from "react";
import { collection, onSnapshot, query, where, orderBy } from "firebase/firestore";
import { FileText, Clock3, CheckCircle2, ArrowUpRight } from "lucide-react";
import { Link } from "react-router-dom";
import { db } from "../firebase";
import { useAuth } from "../auth/AuthContext";
import { StatusPill } from "./Requests.jsx";

export default function Portal() {
  const { user } = useAuth();
  const [requests, setRequests] = useState([]);
  const [error, setError] = useState("");
  useEffect(() => {
    if (!user) return;
    const q = query(collection(db, "requests"), where("citizenUid", "==", user.uid), orderBy("createdAt", "desc"));
    return onSnapshot(q, snap => {setRequests(snap.docs.map(d=>({id:d.id,...d.data()})));setError("");}, () => setError("Δεν ήταν δυνατή η φόρτωση των αιτημάτων."));
  }, [user]);
  const pending = requests.filter(r => !["completed","rejected"].includes(r.status)).length;
  const completed = requests.filter(r => r.status === "completed").length;
  return <div className="content-stack">
    <div className="page-heading"><div><p className="eyebrow dark">ΠΡΟΣΩΠΙΚΗ ΠΕΡΙΟΧΗ</p><h1>Καλώς ήρθατε</h1><p className="muted">Υποβάλετε αιτήματα και παρακολουθήστε την εξέλιξή τους.</p></div><Link className="primary-link" to="/portal/new-request">+ Νέο αίτημα</Link></div>
    <div className="stats-grid"><Stat icon={<FileText/>} label="Συνολικά αιτήματα" value={requests.length}/><Stat icon={<Clock3/>} label="Σε εξέλιξη" value={pending}/><Stat icon={<CheckCircle2/>} label="Ολοκληρωμένα" value={completed}/></div>
    <section className="panel"><div className="panel-heading"><div><h2>Τα αιτήματά μου</h2><p>Μόνο αιτήματα του συνδεδεμένου λογαριασμού.</p></div><FileText size={21}/></div>
      {error && <div className="error-box">{error}</div>}
      {requests.length === 0 ? <div className="empty-state"><div className="empty-icon"><FileText size={26}/></div><h3>Δεν υπάρχουν αιτήματα</h3><p>Όταν υποβάλετε αίτημα, θα εμφανίζεται εδώ.</p><Link to="/portal/new-request" className="text-link">Υποβολή αιτήματος <ArrowUpRight size={15}/></Link></div> :
        <div className="request-list">{requests.map(r=><div className="request-row" key={r.id}><div className="request-symbol"><FileText size={20}/></div><div className="request-info"><strong>{r.type}</strong><small>Κωδικός: {r.id}</small><small>{formatDate(r.createdAt)}</small></div><StatusPill status={r.status}/></div>)}</div>}
    </section>
  </div>;
}
function Stat({icon,label,value}) { return <div className="stat-card"><div className="stat-top"><span>{label}</span><span className="stat-icon">{icon}</span></div><strong>{value}</strong></div>; }
function formatDate(ts) { return ts?.toDate ? ts.toDate().toLocaleDateString("el-GR") : "Μόλις υποβλήθηκε"; }