import { useEffect, useRef, useState } from "react";
import { RecaptchaVerifier, signInWithPhoneNumber, signInWithEmailAndPassword } from "firebase/auth";
import { useNavigate } from "react-router-dom";
import { Landmark, ShieldCheck, Smartphone, Mail } from "lucide-react";
import { auth, authPersistenceReady } from "../firebase";
import { useAuth } from "../auth/AuthContext";

export default function Login() {
  const [mode, setMode] = useState("citizen");
  const [phone, setPhone] = useState("+30");
  const [code, setCode] = useState("");
  const [confirmation, setConfirmation] = useState(null);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const recaptcha = useRef(null);
  const verifier = useRef(null);
  const navigate = useNavigate();
  const { user, isAdmin, profile, loading } = useAuth();

  useEffect(() => {
    if (!loading && user) {
      if (isAdmin) navigate("/admin", { replace: true });
      else if (profile?.status === "approved") navigate("/portal", { replace: true });
      else navigate("/verification", { replace: true });
    }
  }, [user, isAdmin, profile, loading, navigate]);

  useEffect(() => () => { if (verifier.current) verifier.current.clear(); }, []);

  async function sendSms(e) {
    e.preventDefault(); setBusy(true); setError("");
    try {
      await authPersistenceReady;
      if (!verifier.current) verifier.current = new RecaptchaVerifier(auth, recaptcha.current, { size: "normal" });
      const result = await signInWithPhoneNumber(auth, phone.trim(), verifier.current);
      setConfirmation(result);
    } catch (err) {
      setError(friendlyError(err));
      if (verifier.current) { verifier.current.clear(); verifier.current = null; }
    } finally { setBusy(false); }
  }
  async function verifySms(e) {
    e.preventDefault(); setBusy(true); setError("");
    try { await confirmation.confirm(code.trim()); }
    catch (err) { setError(friendlyError(err)); }
    finally { setBusy(false); }
  }
  async function adminLogin(e) {
    e.preventDefault(); setBusy(true); setError("");
    try { await authPersistenceReady; await signInWithEmailAndPassword(auth, email.trim(), password); }
    catch (err) { setError("Η σύνδεση απέτυχε. Έλεγξε τα στοιχεία ή επικοινώνησε με τον διαχειριστή συστήματος."); }
    finally { setBusy(false); }
  }

  return <div className="login-page">
    <div className="login-decoration"><div className="decor-circle circle-one"/><div className="decor-circle circle-two"/><div className="login-hero"><div className="hero-emblem"><Landmark size={34}/></div><p className="eyebrow">ΨΗΦΙΑΚΕΣ ΥΠΗΡΕΣΙΕΣ</p><h1>Το Δημοτολόγιο,<br/>πιο κοντά σας.</h1><p className="hero-copy">Ασφαλής πρόσβαση σε ηλεκτρονικές υπηρεσίες και αιτήματα του Δήμου.</p><div className="hero-note"><ShieldCheck size={18}/> Προστατευμένη πρόσβαση χρηστών</div></div></div>
    <div className="login-panel"><div className="login-card">
      <div className="mobile-brand"><Landmark size={24}/><strong>Δημοτολόγιο</strong></div>
      <p className="eyebrow dark">ΚΑΛΩΣ ΗΡΘΑΤΕ</p><h2>Σύνδεση</h2><p className="muted">Επιλέξτε τον τρόπο πρόσβασης.</p>
      <div className="mode-switch"><button className={mode === "citizen" ? "active" : ""} onClick={() => {setMode("citizen");setError("");}}>Πολίτης</button><button className={mode === "admin" ? "active" : ""} onClick={() => {setMode("admin");setError("");}}>Διαχειριστής</button></div>
      {mode === "citizen" ? !confirmation ? <form onSubmit={sendSms} className="form-stack">
        <label>Αριθμός κινητού</label><div className="input-wrap"><Smartphone size={18}/><input value={phone} onChange={e=>setPhone(e.target.value)} placeholder="+30 69XXXXXXXX" autoComplete="tel" required /></div>
        <p className="hint">Θα λάβετε κωδικό SMS. Χρησιμοποιήστε διεθνή μορφή, π.χ. +30.</p>
        <div id="recaptcha-container" ref={recaptcha}/>
        <button className="primary-button" disabled={busy}>{busy ? "Αποστολή…" : "Αποστολή κωδικού SMS"}</button>
      </form> : <form onSubmit={verifySms} className="form-stack">
        <label>Κωδικός επαλήθευσης SMS</label><div className="input-wrap"><Smartphone size={18}/><input value={code} onChange={e=>setCode(e.target.value)} inputMode="numeric" autoComplete="one-time-code" placeholder="123456" required /></div>
        <button className="primary-button" disabled={busy}>{busy ? "Έλεγχος…" : "Επιβεβαίωση και σύνδεση"}</button>
        <button type="button" className="text-button" onClick={()=>{setConfirmation(null);setCode("");setError("");}}>Αλλαγή αριθμού</button>
      </form> : <form onSubmit={adminLogin} className="form-stack">
        <label>Υπηρεσιακό email</label><div className="input-wrap"><Mail size={18}/><input type="email" value={email} onChange={e=>setEmail(e.target.value)} autoComplete="username" required /></div>
        <label>Κωδικός πρόσβασης</label><input className="plain-input" type="password" value={password} onChange={e=>setPassword(e.target.value)} autoComplete="current-password" required />
        <button className="primary-button" disabled={busy}>{busy ? "Σύνδεση…" : "Σύνδεση διαχειριστή"}</button>
      </form>}
      {error && <div className="error-box" role="alert">{error}</div>}
      <div className="login-foot"><ShieldCheck size={16}/> Τα στοιχεία σας προστατεύονται με έλεγχο πρόσβασης.</div>
      <p className="legal-note">Η επιβεβαίωση τηλεφώνου δεν ισοδυναμεί με επιβεβαίωση δημοτολογικής ιδιότητας. Η πρόσβαση στις υπηρεσίες ενεργοποιείται μετά από έλεγχο υπαλλήλου.</p>
    </div></div>
  </div>;
}
function friendlyError(err) {
  const code = err?.code || "";
  if (code.includes("invalid-phone-number")) return "Ο αριθμός τηλεφώνου δεν είναι έγκυρος. Χρησιμοποίησε διεθνή μορφή.";
  if (code.includes("too-many-requests")) return "Έγιναν πολλές προσπάθειες. Δοκίμασε αργότερα.";
  if (code.includes("captcha")) return "Ο έλεγχος ασφαλείας απέτυχε. Ανανέωσε τη σελίδα και προσπάθησε ξανά.";
  if (code.includes("invalid-verification-code")) return "Ο κωδικός SMS δεν είναι σωστός.";
  return "Δεν ήταν δυνατή η ολοκλήρωση. Έλεγξε τη σύνδεση και προσπάθησε ξανά.";
}