import { initializeApp } from "firebase-admin/app";
import { getAuth } from "firebase-admin/auth";
import { getFirestore, FieldValue } from "firebase-admin/firestore";
import { onCall, HttpsError } from "firebase-functions/v2/https";
import { setGlobalOptions } from "firebase-functions/v2";

initializeApp();
setGlobalOptions({ region: "europe-west1", maxInstances: 10 });
const db = getFirestore();
const auth = getAuth();

function requireAdmin(request) {
  if (!request.auth || request.auth.token.admin !== true) {
    throw new HttpsError("permission-denied", "Απαιτείται ρόλος διαχειριστή.");
  }
}
function cleanString(value, max = 1000) {
  if (typeof value !== "string") return "";
  return value.trim().slice(0, max);
}
async function audit({ actorUid, action, targetType, targetId, metadata = {} }) {
  await db.collection("auditLogs").add({
    actorUid, action, targetType, targetId, metadata,
    createdAt: FieldValue.serverTimestamp()
  });
}

// Creates only a minimal pending profile. A phone-verified account is NOT a verified citizen.
export const ensureCitizenProfile = onCall({ enforceAppCheck: true }, async (request) => {
  if (!request.auth) throw new HttpsError("unauthenticated", "Απαιτείται σύνδεση.");
  if (request.auth.token.admin === true) return { role: "admin" };
  const uid = request.auth.uid;
  const phoneNumber = request.auth.token.phone_number || "";
  const ref = db.collection("users").doc(uid);
  await db.runTransaction(async tx => {
    const snap = await tx.get(ref);
    if (!snap.exists) {
      tx.create(ref, {
        role: "citizen",
        status: "pending",
        phoneNumber,
        createdAt: FieldValue.serverTimestamp(),
        updatedAt: FieldValue.serverTimestamp()
      });
    } else {
      // Never allow this function to change role or approval state.
      tx.update(ref, {
        phoneNumber,
        updatedAt: FieldValue.serverTimestamp()
      });
    }
  });
  return { role: "citizen", status: (await ref.get()).data()?.status || "pending" };
});

// Manual verification by an authorized admin. Record only minimal, non-sensitive notes.
export const reviewCitizen = onCall({ enforceAppCheck: true }, async (request) => {
  requireAdmin(request);
  const uid = cleanString(request.data?.uid, 128);
  const decision = request.data?.decision;
  const note = cleanString(request.data?.note, 500);
  if (!uid || !["approved", "rejected"].includes(decision)) {
    throw new HttpsError("invalid-argument", "Μη έγκυρα στοιχεία ελέγχου.");
  }
  const ref = db.collection("users").doc(uid);
  const snap = await ref.get();
  if (!snap.exists || snap.data()?.role !== "citizen") {
    throw new HttpsError("not-found", "Δεν βρέθηκε λογαριασμός πολίτη.");
  }
  await ref.update({
    status: decision,
    reviewedBy: request.auth.uid,
    reviewedAt: FieldValue.serverTimestamp(),
    reviewNote: note,
    updatedAt: FieldValue.serverTimestamp()
  });
  await audit({
    actorUid: request.auth.uid,
    action: decision === "approved" ? "citizen_approved" : "citizen_rejected",
    targetType: "user",
    targetId: uid,
    metadata: { note }
  });
  return { ok: true, status: decision };
});

export const updateRequestStatus = onCall({ enforceAppCheck: true }, async (request) => {
  requireAdmin(request);
  const requestId = cleanString(request.data?.requestId, 128);
  const status = request.data?.status;
  const note = cleanString(request.data?.note, 1000);
  const allowed = ["submitted", "in_review", "needs_info", "completed", "rejected"];
  if (!requestId || !allowed.includes(status)) {
    throw new HttpsError("invalid-argument", "Μη έγκυρος κωδικός ή κατάσταση αιτήματος.");
  }
  const ref = db.collection("requests").doc(requestId);
  const snap = await ref.get();
  if (!snap.exists) throw new HttpsError("not-found", "Το αίτημα δεν βρέθηκε.");
  const before = snap.data();
  await ref.update({
    status,
    updatedAt: FieldValue.serverTimestamp(),
    lastUpdatedBy: request.auth.uid,
    lastNote: note
  });
  await audit({
    actorUid: request.auth.uid,
    action: "request_status_changed",
    targetType: "request",
    targetId: requestId,
    metadata: { from: before.status || "submitted", to: status, note }
  });
  return { ok: true, status };
});

// Admin provisioning is intentionally NOT exposed as a public callable function.
// Use the documented trusted Admin SDK script/CLI procedure.
