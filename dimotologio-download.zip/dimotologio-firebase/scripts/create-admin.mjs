/**
 * Run only from a trusted administrator workstation / secure deployment environment.
 * Requires Application Default Credentials (gcloud auth application-default login)
 * or GOOGLE_APPLICATION_CREDENTIALS pointing to a service-account key kept OUTSIDE this repo.
 *
 * Usage: node scripts/create-admin.mjs admin@example.gov.gr
 */
import { initializeApp, applicationDefault } from "firebase-admin/app";
import { getAuth } from "firebase-admin/auth";
import { getFirestore, FieldValue } from "firebase-admin/firestore";

const email = process.argv[2]?.trim().toLowerCase();
if (!email || !email.includes("@")) {
  console.error("Usage: node scripts/create-admin.mjs admin@example.gov.gr");
  process.exit(1);
}
initializeApp({ credential: applicationDefault() });
const auth = getAuth();
const db = getFirestore();
const user = await auth.getUserByEmail(email);
await auth.setCustomUserClaims(user.uid, { ...(user.customClaims || {}), admin: true });
await db.collection("users").doc(user.uid).set({
  role: "admin",
  status: "approved",
  email: user.email,
  updatedAt: FieldValue.serverTimestamp()
}, { merge: true });
await db.collection("auditLogs").add({
  actorUid: "bootstrap-script",
  action: "admin_role_assigned",
  targetType: "user",
  targetId: user.uid,
  metadata: { email },
  createdAt: FieldValue.serverTimestamp()
});
console.log(`Admin role assigned to ${email} (${user.uid}). Sign out and sign in again to refresh claims.`);
